import numpy as np 

def get_light_curve_from_gstor(ra, dec):
	 healpy.ang2pix(128, np.radians((star_dec*-1.0) + 90.0), np.radians(360.0 - star_ra)) 