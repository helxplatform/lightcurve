import datetime, json, io, pickle, os, time, sys, base64, csv

from flask import Flask, render_template, send_file

from PIL import Image, ImageDraw

import jinja2

from bokeh.embed import json_item
from bokeh.plotting import figure
from bokeh.layouts import column
from bokeh.resources import CDN
from bokeh.models import CustomJS, ColumnDataSource, TapTool, Circle, RangeTool, WheelZoomTool, NumeralTickFormatter

 
import astropy.wcs
import astropy.units as u
import astropy.coordinates

import google_cloud
import numpy as np

app = Flask(__name__)

# test with python main.py
# Deploy to App Engine using: https://cloud.google.com/appengine/docs/standard/python3/building-app/deploying-web-service
# gcloud app deploy
# gcloud app browse
# log viewer page: https://console.cloud.google.com/logs/viewer
def targetid_from_radec(ra,dec):
    return "EVRJ%.3f%+.3f"%(ra,dec)

def jinga_render(template_name, **kwargs):
    templateLoader = jinja2.FileSystemLoader(searchpath="./templates/")
    templateEnv = jinja2.Environment(loader=templateLoader, autoescape=True) # autoescape off needed for header include, but may be vulnerable
    template = templateEnv.get_template(template_name)
    return template.render(kwargs)

def check_rate_limit():
    # this is a kill switch if something decides to crawl the entire DB
    # will only kill this one instance (although others should rapidly die if this is a real problem...)
    # /tmp is stored in a ramdisk per instance
    
    try:
        last_access_time = os.path.getmtime("/tmp/access_log.txt")
    except FileNotFoundError:
         last_access_time = time.time()

    if time.time() - last_access_time > 3600.0:
        with open("/tmp/access_log.txt","w") as last_access_log:
            print (datetime.datetime.now(), file=last_access_log)
    else:
        with open("/tmp/access_log.txt","a") as last_access_log:
            print (datetime.datetime.now(), file=last_access_log)

    with open("/tmp/access_log.txt","r") as last_access_log:
        n_recent_connections = len(last_access_log.readlines())
        if n_recent_connections > 2000:
            print ("Exceeded maximum connections, with %i connections" % n_recent_connections)
            sys.exit(1)

def sigma_clip(x,sigma,niter):
    x = np.array(x)
    if len(x) > 3:
       for i in range(niter):
           xt = x-np.mean(x)
           x = x[np.where(abs(xt) < sigma*np.std(xt))]
    return x



def make_lc_download(ra, dec, format):
    gstor = google_cloud.google_storage()

    lc = gstor.get_light_curve(ra, dec)

    mjds = lc.mjds
    mags = lc.mags 
    magerrs = lc.magerrs
    limmags = lc.limmags
    qualities = lc.quality 
    cameras = lc.cameras
    ratchets = lc.ratchetids

    targetid = targetid_from_radec(ra,dec)

    if format == "txt":
        out_string = io.StringIO()
        print ("#","%10s"%"MJD", "%8s"%"g-mag", "%8s"%"magerr", "%6s"%"limmag", "%5s"%"quality", "%7s"%"camera", "ratchetID", file=out_string)
        for epoch, mag, magerr, limmag, quality, camera, ratchet in zip(mjds,mags,magerrs,limmags,qualities,cameras,ratchets):
            print ("%12.6f"%epoch, "%8.4f"%mag, "%8.4f"%magerr, "%6.2f"%limmag, "%6.2f"%quality, "ML"+"%i"%camera, ratchet, file=out_string)

        # encode to bytes-format output
        mem = io.BytesIO()
        mem.write(out_string.getvalue().encode('utf-8'))
        mem.seek(0)
        return send_file(mem, as_attachment=True, attachment_filename=targetid+".txt",mimetype='text/plain')

    if format == "csv":
        out_string = io.StringIO()
        writer = csv.writer(out_string)
        writer.writerow(["MJD", "g-mag", "magerr", "limmag", "quality", "camera", "ratchetID"])
        for epoch, mag, magerr, limmag, quality, camera, ratchet in zip(mjds,mags,magerrs,limmags,qualities,cameras,ratchets):
            writer.writerow([epoch, mag, magerr, limmag, quality, camera, ratchet])

        # encode to bytes-format output
        mem = io.BytesIO()
        mem.write(out_string.getvalue().encode('utf-8'))
        mem.seek(0)
        out_string.close()
        return send_file(mem, as_attachment=True, attachment_filename=targetid+".csv",mimetype='text/csv')

    return None

def make_plot(ra, dec):
    print ("Making plot")

    gstor = google_cloud.google_storage()

    lc = gstor.get_light_curve(ra, dec)

    mjds = lc.mjds
    mags = lc.mags 
    magerrs = lc.magerrs
    limmags = lc.limmags
    quality = lc.quality 
    cameras = lc.cameras
    ratchets = lc.ratchetids
    filenames = lc.filenames

    if mjds is None:
            mjds = np.zeros(1)
            mags = np.zeros(1)
            magerrs = np.zeros(1)
            limmags = np.zeros(1)
            quality = np.zeros(1)
            cameras = np.zeros(1)
            ratchets = np.zeros(1)
            filenames = np.zeros(1)

            
    print (mjds.shape)

    mask = (magerrs < 1.0) & (mags > 5) & (quality < 10000.0)
    mjds = mjds[mask]
    mags = mags[mask]
    magerrs = magerrs[mask]
    quality = quality[mask]
    limmags = limmags[mask]
    cameras = cameras[mask]
    ratchets = ratchets[mask]
    filenames = filenames[mask]

    #print ("Mageers:", magerrs, "libmags:", limmags)

    best_ratchetcamera_n = np.argmin(magerrs)
    best_ratchetcamera = "%i_%i" % (cameras[best_ratchetcamera_n], ratchets[best_ratchetcamera_n])

    cameraratchets = []
    for c,r in zip(cameras,ratchets):
        cameraratchets.append("%i_%i"%(c,r))

    mags_middle = np.median(mags)
    mags_high = np.max(mags) - mags_middle
    mags_low = mags_middle - np.min(mags)
    if mags_high < 0.5:
        mags_high = 0.5
    if mags_low < 0.5:
        mags_low = 0.5

    p = figure(title = "", 
                sizing_mode="stretch_width", 
                plot_width=900, 
                plot_height=300, 
                toolbar_location="right",
                tools="box_zoom, pan, wheel_zoom, reset",
                active_drag="pan",
                #x_axis_location="above",
                background_fill_color="#efefef",
                x_range=(np.min(mjds)-10,np.max(mjds)+10),
                y_range=(mags_middle + mags_high*1.5, mags_middle - mags_low*1.5),
                margin=(10,10,10,10),
                output_backend="webgl"
                )

    p.axis.axis_label_text_font_style = 'bold'
    p.axis.axis_label_text_font_size = "12pt"
    

    p.yaxis[0].formatter = NumeralTickFormatter(format="0.00")

    p.border_fill_alpha = 0.0
    p.outline_line_color = "black"

    select = figure(title="MJD range selector",
                plot_height=100, 
                plot_width=900, 
                y_range=(mags_middle + mags_high*5.5, mags_middle - mags_low*5.5),
                x_range=(np.min(mjds)-30,np.max(mjds)+30), 
                y_axis_type=None,
                x_axis_location="above",
                tools="", 
                sizing_mode="stretch_width", 
                toolbar_location=None, 
                background_fill_color="#efefef",
                margin=(0,10,0,10),
                output_backend="webgl"
                )

    p.toolbar.active_scroll = p.select_one(WheelZoomTool)

    select.axis.axis_label_text_font_style = 'bold' 
    select.outline_line_color = "black"

    p.xaxis.axis_label = "MJD"
    #select.xaxis.axis_label = "MJD range selection"
    p.yaxis.axis_label = "Evryscope-mag"

    p.yaxis.major_label_text_font_size = "12pt"
    p.xaxis.major_label_text_font_size = "12pt"
    select.xaxis.major_label_text_font_size = "12pt"

    p.toolbar.logo = None

    camera_dict = {}
    for n,camera in enumerate(set(cameras)):
        camera_dict[camera] = n
    color_cameras = []
    for c in cameras:
        color_cameras.append(camera_dict[c])
    color_cameras = np.array(color_cameras)
    cameraratchets = np.array(cameraratchets)

    sortorder = np.argsort(mjds)

    mjds = mjds[sortorder]
    mags = mags[sortorder]
    magerrs = magerrs[sortorder]
    quality = quality[sortorder]
    limmags = limmags[sortorder]
    cameras = cameras[sortorder]
    ratchets = ratchets[sortorder]
    filenames = filenames[sortorder]


    color_val = quality
    color_r = (1.0-color_val)
    color_g = (1.0-color_val)
    color_b = (1.0-color_val)

    """
    color_r[color_val > 0.333333] = 1.0
    color_g[color_val > 0.333333] = (color_val[color_val > 0.333333]-0.33333)/0.33333
    color_b[color_val > 0.333333] = 0.0

    color_r[color_val > 0.66666] = 1.0
    color_g[color_val > 0.66666] = 1.0
    color_b[color_val > 0.66666] = (color_val[color_val > 0.666666]-0.66666666)/0.3333333
    """

    data = {
    'mjds': mjds,
    'mags': mags,
    'color': ["#%02x%02x%02x" % (int(r_color*255.0), int(g_color*255.0), int(b_color*255.0)) for r_color, g_color, b_color in zip(color_r, color_g, color_b)],
    'cameraratchets': cameraratchets,
    'star_ra': np.ones(len(mjds))*ra,
    'star_dec': np.ones(len(mjds))*dec # for later position changes with time
    }
    
    target_info = "<h3>Target info</h3>" + "<p>" 
    target_info+= "<table>"
    target_info+= "<tr><td>Position:</td> <td>%.4f, %.4f</td></tr>" % (ra,dec)
    target_info+= "<tr><td>Evryscope g-mag:</td> <td>%.2f</td></tr>" % (np.median(mags))
    target_info+= f"<tr><td>Epochs:</td> <td>{len(mjds):,}</td></tr>"
    target_info+= "<tr><td>Survey length: </td> <td>%i d</td></tr>" % int((np.max(mjds) - np.min(mjds)))
    target_info+= "<tr><td>Unique nights: </td> <td>%i </td></tr>" % len(set(mjds.astype(np.int32)))
    target_info+= "</table>"
    data = ColumnDataSource(data)

    click_point_callback = CustomJS(args={"current_src": data}, code=open("templates/get_image.js","r").read())
    tap = TapTool(callback=click_point_callback)

    #p.line('mjds', 'mags', source=data, line_color="black")
    p.circle('mjds', 'mags', size=5.0, fill_alpha=0.5, source=data, line_color=None)
    #renderer = p.circle('mjds', 'mags', color=(100,100,255), fill_alpha=0.2, size=6, source=data, nonselection_fill_color='color')
    p.tools.append(tap)

    #renderer.selection_glyph = Circle(fill_alpha=1.0, fill_color=(100,100,255), line_color="blue")
    #renderer.nonselection_glyph = Circle(fill_alpha=0.2, fill_color=(100,100,255), line_color="blue")
    
    range_tool = RangeTool(x_range=p.x_range)
    range_tool.overlay.fill_color = "navy"
    range_tool.overlay.fill_alpha = 0.2

    select.circle('mjds', 'mags', color=(100,100,255), source=data)
    select.ygrid.grid_line_color = None
    select.add_tools(range_tool)
    select.toolbar.active_multi = range_tool
    

    # make the light curve table
    lc_table = """
        <div class="scrollingtable" id="lc_table_scroll">
        <div id="lc_table_scroll2">
            <div id="lc_table_scroll3">
                <table id="lc_table_id">
                    <!-- <caption>Top Caption</caption> -->
                    <thead>
                        <tr>
                         <th><div label="MJD"></div></th>
                         <th><div label="g-mag"></div></th>
                         <th><div label="Magerr"></div></th>
                         <th><div label="Lim-mag"></div></th>
                         <th><div label="Quality (0..1)"></div></th>
                         <th><div label="Camera"></div></th>
                         <th><div label="RatchetID"></div></th>
                         <th><div label="Filename"></div></th>
              <th class="scrollbarhead"></th> <!--ALWAYS ADD THIS EXTRA CELL AT END OF HEADER ROW-->
                        </tr>
                    </thead>
                    <tbody>                        
    """
    
    for n in range(len(mjds)):
        lc_table+= "<tr><td>%.6f</td> <td>%.3f</td> <td>%.3f</td> <td>%.2f</td> <td>%.2f</td> <td>ML%s</td> <td>%s</td> <td>%s</td></tr>" % (mjds[n], mags[n], magerrs[n], limmags[n], quality[n], cameras[n], ratchets[n], filenames[n])
    
    lc_table+= """
               </tbody>
                </table>
            </div>
        </div>
        </div>
    """
    print ("Finished plot")
    return column([select, p]), best_ratchetcamera, target_info, lc_table

def make_image(ra, dec, cameraratchet, width, height, plot_stars):
    gstor = google_cloud.google_storage()
    camera, ratchetid = cameraratchet.split("_")
    print (camera, ratchetid)
    image_data = gstor.download_ratchet_image(camera, ratchetid)
    header = gstor.download_ratchet_image_header(camera, ratchetid)
    wcs = astropy.wcs.WCS(header)

    tx, ty = wcs.all_world2pix(ra,dec,0)

    # make a large cutout around that area, for rotation
    image = Image.open(io.BytesIO(image_data))
    width = int(width)
    height = int(height)
    image = image.crop((tx-width/2,ty-height/2,tx+width/2,ty+height/2))
    image = image.convert("RGB")

    draw = ImageDraw.Draw(image)
    cx, cy = image.width / 2, image.height / 2
    marker_len = 10
    marker_skip = 5
    
    if plot_stars == True:
        # plot all nearby stars in DB
        gstor = google_cloud.google_storage()
        lcs, mpix_boundaries = gstor.get_light_curve(ra, dec, return_list_all=True, return_minipix_boundaries=True)

        mpix_boundaries_pixels = wcs.all_world2pix(mpix_boundaries,0)
        mpix_boundaries_pixels[:,0]-=(tx-width/2)
        mpix_boundaries_pixels[:,1]-=(ty-height/2)

        print (mpix_boundaries_pixels)

        for n in range(len(mpix_boundaries_pixels)-1):
            draw.line((mpix_boundaries_pixels[n,0],mpix_boundaries_pixels[n,1],mpix_boundaries_pixels[n+1,0],mpix_boundaries_pixels[n+1,1]), fill=(255,255,255),width=2)

        draw.line((mpix_boundaries_pixels[0,0],mpix_boundaries_pixels[0,1],mpix_boundaries_pixels[len(mpix_boundaries_pixels)-1,0],mpix_boundaries_pixels[len(mpix_boundaries_pixels)-1,1]), fill=(255,255,255),width=2)

        for lc in lcs:
            print (lc[2],lc[3])
            lx, ly = wcs.all_world2pix(lc[2],lc[3],0)
            lx-=tx
            ly-=ty
            lx+=width/2
            ly+=height/2
            marker_rad = 4
            
            draw.ellipse((lx-marker_rad,ly-marker_rad,lx+marker_rad,ly+marker_rad), outline=(50,255,70))

    draw.line((cx - marker_skip, cy, cx - marker_skip - marker_len, cy), fill=(255,50,100),width=2)
    draw.line((cx + marker_skip, cy, cx + marker_skip + marker_len, cy), fill=(255,50,100),width=2)
    draw.line((cx, cy - marker_skip, cx, cy - marker_skip - marker_len), fill=(255,50,100),width=2)
    draw.line((cx, cy + marker_skip, cx, cy + marker_skip + marker_len), fill=(255,50,100),width=2)


    image_byte_array = io.BytesIO()
    image.save(image_byte_array,format='png',quality=99)

    return image_byte_array.getvalue()

def make_targets_table(ra,dec):
    gstor = google_cloud.google_storage()

    lcs = gstor.get_light_curve(ra, dec, return_list_all=True)

    sidebar_items = ""

    out = """<div class="table_container"><div class="table">"""
    out+= """<div class="table-content">\n"""

    out+="""
            <div class="table-row-header">
                <div class="table-data header-item"><a id="sep" class="filter__link filter__link--number" href="#">Sep. / arcmin</a></div>
                <div class="table-data header-item"><a id="target_id" class="filter__link filter__link--number" href="#">ID</a></div>
                <div class="table-data header-item"><a id="RA" class="filter__link filter__link--number" href="#">RA / deg</a></div>
                <div class="table-data header-item"><a id="Dec" class="filter__link filter__link--number" href="#">Dec / deg</a></div>
                <div class="table-data header-item"><a id="Evrymag" class="filter__link filter__link--number" href="#">Evry-mag (g)</a></div>
                <div class="table-data header-item"><a id="Epochs" class="filter__link filter__link--number" href="#"># Epochs</a></div>
                <div class="table-data header-item"><a id="StartMJD" class="filter__link filter__link--number" href="#">StartMJD</a></div>
                <div class="table-data header-item"><a id="EndMJD" class="filter__link filter__link--number" href="#">EndMJD</a></div>
                <div class="table-data header-item"><a id="magstd" class="filter__link filter__link--number" href="#">Mags-std</a></div>
            </div>
    """

    for lc in sorted(lcs):
        out+="""<div class="table-row">\n"""
        out+="""<div class="table-data">""" + ("%.2f" % lc[0].to_value(u.arcmin)) + "</div>\n"
        target_id = targetid_from_radec(lc[2],lc[3])
        out+="""<div class="table-data">""" + "<a href=\"\\dynamic\\target_display\\" + ("%.5f"%lc[2]) + "\\" + ("%.5f"%lc[3]) + ("\">%s</a>"%target_id)  + "</div>\n"
        out+="""<div class="table-data">""" + ("%.4f"%lc[2]) + "</div>\n"
        out+="""<div class="table-data">""" + ("%.4f"%lc[3]) + "</div>\n"
        out+="""<div class="table-data">""" + ("%.2f"%np.median(sigma_clip(lc[4].mags,5,1))) + "</div>\n"
        out+="""<div class="table-data">""" + ("%i"%len(lc[4].mags)) + "</div>\n"
        out+="""<div class="table-data">""" + ("%.2f"%np.min(lc[4].mjds)) + "</div>\n"
        out+="""<div class="table-data">""" + ("%.2f"%np.max(lc[4].mjds)) + "</div>\n"
        out+="""<div class="table-data">""" + ("%.2f"%np.std(sigma_clip(lc[4].mags,5,1))) + "</div>\n"
        out+="</div>\n"
    out+="</div>\n"
    out+="</div></div>\n"



    sidebar_items+="<h2>Nearby stars list</h2>"
    sidebar_items+="<table><tr><td>Query target:</td><td> %.4f, %.4f</td></tr>" % (ra, dec)
    galactic_coords = astropy.coordinates.SkyCoord(ra*u.deg, dec*u.deg, frame='icrs').galactic
    sidebar_items+="<tr><td>Galactic coordinates:</td><td> %.4f, %.4f</td></tr>" % (galactic_coords.l.degree, galactic_coords.b.degree)

    best_match_lc = lcs[0][4]

    # find best cameraratchet for closest match
    best_ratchetcamera_n = np.argmin(best_match_lc.magerrs)
    best_ratchetcamera = "%i_%i" % (best_match_lc.cameras[best_ratchetcamera_n], best_match_lc.ratchetids[best_ratchetcamera_n])

    sidebar_items+="<tr><td>Stars in closest minipix:</td><td> %i</td></tr>" % (len(lcs))
    sidebar_items+="</table>  <hr>"
    sidebar_items+="<p class=\"sidebar_element_title\">Evryscope image of region</p>"

    sidebar_items+="<img width=\"100%\" src=\"/dynamic/image/" + repr(ra) + "/" + repr(dec) + "/" + best_ratchetcamera + "/300/200/plot_stars=True\">"
    sidebar_items+="<p class=\"expln_text\">red crosshair = ra,dec</p>"
    sidebar_items+="<p class=\"expln_text\">green circles = stars in DB</p>"
    sidebar_items+="<p class=\"expln_text\">white lines = boundary of query region</p>"



    return out, sidebar_items

@app.route('/',methods=['GET'])
def root():
    check_rate_limit()
    return jinga_render("main_page.html", title="Evryscope Light Curves Server")

@app.route('/dynamic/target_list/<string:ra>/<string:dec>',methods=['GET'])
def target_list(ra,dec):
    check_rate_limit()
    ra = float(ra)
    dec = float(dec)
    target_list, sidebar_items = make_targets_table(ra,dec)

    return jinga_render("target_list.html", title="Evryscope targets for %.4f, %.4f" % (ra,dec), sidebar_items = sidebar_items, target_list = target_list)

@app.route('/dynamic/target_display/<string:ra>/<string:dec>',methods=['GET'])
def target_display(ra,dec):
    check_rate_limit()
    ra = float(ra)
    dec = float(dec)
    return jinga_render("target_display.html",resources=CDN.render(),star_ra=ra,star_dec=dec,sidebar_items="")

@app.route('/dynamic/plot/<string:ra>/<string:dec>')
def plot(ra,dec):
    check_rate_limit()
    ra = float(ra)
    dec = float(dec)
    p, image_spec, target_info, lc_table = make_plot(ra,dec)
    return json.dumps([json_item(p, "lc_plot"), [ra,dec,image_spec], target_info, lc_table])

@app.route('/dynamic/download_lc/<string:ra>/<string:dec>/<string:format>')
def download_lc(ra,dec,format):
    check_rate_limit()
    ra = float(ra)
    dec = float(dec)
    output_format = None
    if format == "txt":
        output_format = "txt"
    elif format == "csv":
        output_format = "csv"
    elif format == "fits":
        output_format = "fits"

    if output_format is not None:
            return make_lc_download(ra,dec,format)
    else:
        return False

@app.route('/dynamic/image/<float(signed=True):ra>/<float(signed=True):dec>/<string:cameraratchet>/<int:width>/<int:height>/<string:plot_stars>/')
def image(ra,dec,cameraratchet,width,height,plot_stars): 
    check_rate_limit()
    if plot_stars == "plot_stars=True":
        plot_stars_flag = True
    else:
        plot_stars_flag = False

    image = make_image(ra,dec,cameraratchet,width,height,plot_stars_flag)

    return send_file(io.BytesIO(image),
                     attachment_filename='image.jpg',
                     mimetype='image/jpg')

"""
@app.route('/')
def root():
    gstor = google_cloud.google_storage()
    files = gstor.list_files()

    return render_template('index.html', files=files)
"""


if __name__ == '__main__':
    # This is used when running locally only. When deploying to Google App
    # Engine, a webserver process such as Gunicorn will serve the app. This
    # can be configured by adding an `entrypoint` to app.yaml.
    # Flask's development server will automatically serve static files in
    # the "static" directory. See:
    # http://flask.pocoo.org/docs/1.0/quickstart/#static-files. Once deployed,
    # App Engine itself will serve those files as configured in app.yaml.
    app.run(host='127.0.0.1', port=8080, debug=True)
    
