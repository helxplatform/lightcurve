import datetime, json, io

from flask import Flask, render_template, send_file

from PIL import Image, ImageDraw

from jinja2 import Template

from bokeh.embed import json_item
from bokeh.plotting import figure
from bokeh.layouts import column
from bokeh.resources import CDN
from bokeh.models import CustomJS, ColumnDataSource, TapTool, Circle, RangeTool, WheelZoomTool

import astropy.wcs

import google_cloud
import numpy as np

app = Flask(__name__)

# test with python main.py
# Deploy to App Engine using: https://cloud.google.com/appengine/docs/standard/python3/building-app/deploying-web-service
# gcloud app deploy
# gcloud app browse
# log viewer page: https://console.cloud.google.com/logs/viewer



main_page = Template("""
<!DOCTYPE html>
<html lang="en">
<head>
  {{ resources }}
  <link rel="stylesheet" type="text/css" href="/static/static.css">
</head>
<body>
   <div id="coords_form">
                <form onsubmit="go_to_targetlist();return false"name="coords_form">
                Target: <input type="text" size="20" id="coords_input" value="{{star_ra}} {{star_dec}}">
                <p>
                <input type="submit" value="Search for light curve" class="button"> 
                </form>
  </div>
</body>  

<script>
function go_to_targetlist()
{
    var coords = document.getElementById("coords_input").value;
    ra = coords.split(" ")[0];
    dec = coords.split(" ")[1];

    var target = "target_list_page/"+ra+"/"+dec;
    
    window.location = target;
}

</script>

""")


target_list_page = Template("""
<!DOCTYPE html>
<html lang="en">
<head>
  {{ resources }}
  <link rel="stylesheet" type="text/css" href="/static/static.css">
</head>
<body>
  {{ target_list}}
</body>  

""")

target_display_page = Template("""
<!DOCTYPE html>
<html lang="en">
<head>
  {{ resources }}
  <link rel="stylesheet" type="text/css" href="/static/static.css">
</head>
<body>
  <div id="lc_display_container">

  <div id="coords_form">
                <form onsubmit="return plot_graph()" name="coords_form">
                Target: <input type="text" size="20" id="coords_input" value="{{star_ra}} {{star_dec}}">
                <p>
                <input type="submit" value="Search for light curve" class="button"> 
                </form>
  </div>

    <div id="top_panel">
        <div id="left_top_panel">

                <div id="target_info">Testing</div>

        </div>

        <div id="skyplot_container">
            <div id="loading_skyplot"><img src="/static/clear.gif" id="loading_skyplot_img"></div>
            <div id="skyplot_div"><img class="sky" src="/static/clear.gif" id="skyplot_img"></div>
        </div>
    </div> 

   <div id="bottom_panel">
         <div id="lc_plot"></div>
    </div>

 </div>

  <script>
  function plot_graph()
  {
    var coords = document.getElementById("coords_input").value;
    ra = coords.split(" ")[0];
    dec = coords.split(" ")[1];
    
    fetch('/plot/'+ ra + '/' + dec)
        .then(function(response) { 
            return response.json(); 
        })
        .then(function(item) { 
             const el = document.getElementById("lc_plot");
             // first remove the previous charts as child
             // like this, bokeh does not let us update a chart
            while (el.hasChildNodes()) {
                el.removeChild(el.lastChild);
            }
            Bokeh.embed.embed_item(item[0],"lc_plot"); 

            var image = document.getElementById("skyplot_img");
            var downloadingImage = new Image();
            downloadingImage.onload = function(){
                image.src = this.src;   
            };
            downloadingImage.src = '/image/' + item[1][0] + '/' + item[1][1] + '/' + item[1][2];
            
            console.log(item[2]);

            console.log(document.getElementById('target_info').innerHTML);
            document.getElementById('target_info').innerHTML = item[2];

            console.log('<img src=\"/image/' + item[1][0] + '/' + item[1][1] + '/' + item[1][2] + '\">');

        })
        .catch(error => console.error(error) );

    return false;
  }
  
  </script>


</body>
<script>
  plot_graph(); 
</script>
""")


get_image_js = """
    var image = document.getElementById("skyplot_img");

    document.getElementById("loading_skyplot_img").src = "/static/loading.gif"; 

    var downloadingImage = new Image();
    downloadingImage.onload = function(){
        image.src = this.src;   
        document.getElementById("loading_skyplot_img").src = "/static/clear.gif"; 
    };
    
    var n = current_src.selected.indices[0];
 
    console.log("****", n, current_src.data['cameraratchets'][n])
    downloadingImage.src = '/image/' + current_src.data['star_ra'][0] + '/' + current_src.data['star_dec'][0] + '/' + current_src.data['cameraratchets'][n];
"""

"""fetch('/plot')
    .then(function(response) { return response.json(); })
    .then(function(item) { return Bokeh.embed.embed_item(item); })"""

def make_plot(ra, dec):
    gstor = google_cloud.google_storage()

    lc = gstor.get_light_curve(ra, dec)

    mjds = lc.mjds
    mags = lc.mags 
    magerrs = lc.magerrs
    limmags = lc.mimmags
    quality = lc.quality 
    cameras = lc.cameras
    ratchets = lc.ratchets

    if mjds is None:
            mjds = np.zeros(1)
            mags = np.zeros(1)
            magerrs = np.zeros(1)
            limmags = np.zeros(1)
            quality = np.zeros(1)
            cameras = np.zeros(1)
            ratchets = np.zeros(1)

    mask = (magerrs < 0.5) & (mags > 5)
    mjds = mjds[mask]
    mags = mags[mask]
    magerrs = magerrs[mask]
    cameras = cameras[mask]
    ratchets = ratchets[mask]

    best_ratchetcamera_n = np.argmin(magerrs)
    best_ratchetcamera = "%i_%i" % (cameras[best_ratchetcamera_n], ratchets[best_ratchetcamera_n])

    cameraratchets = []
    for c,r in zip(cameras,ratchets):
        cameraratchets.append("%i_%i"%(c,r))

    mags_middle = np.median(mags)
    mags_high = np.max(mags) - mags_middle
    mags_low = mags_middle - np.min(mags)
    if mags_high < 0.5:
        mags_high = 0.5
    if mags_low < 0.5:
        mags_low = 0.5


    p = figure(title = "Evryscope Light Curve", 
                sizing_mode="stretch_width", 
                plot_width=1100, 
                plot_height=400, 
                toolbar_location="above", 
                tools="ywheel_zoom",
                x_axis_location="above",
                background_fill_color="#efefef",
                x_range=(np.min(mjds)-10,np.max(mjds)+10),
                y_range=(mags_middle + mags_high*1.5, mags_middle - mags_low*1.5)
                )

    p.axis.axis_label_text_font_style = 'bold'

    select = figure(title="",
                plot_height=130, 
                plot_width=1100, 
                y_range=(12,8),
                x_range=(np.min(mjds)-30,np.max(mjds)+30), 
                y_axis_type=None,
                tools="", 
                sizing_mode="stretch_width", 
                toolbar_location=None, 
                background_fill_color="#efefef")

    p.toolbar.active_scroll = p.select_one(WheelZoomTool)

    select.axis.axis_label_text_font_style = 'bold' 

    p.xaxis.axis_label = "MJD"
    select.xaxis.axis_label = "MJD"
    p.yaxis.axis_label = "Evryscope-mag"

    p.toolbar.logo = None

    print (cameras)
    camera_dict = {}
    for n,camera in enumerate(set(cameras)):
        camera_dict[camera] = n
    color_cameras = []
    for c in cameras:
        color_cameras.append(camera_dict[c])
    color_cameras = np.array(color_cameras)
    cameraratchets = np.array(cameraratchets)

    sortorder = np.argsort(mjds)

    data = {
    'mjds': mjds[sortorder],
    'mags': mags[sortorder],
    'color': color_cameras[sortorder],
    'cameraratchets': cameraratchets[sortorder],
    'star_ra': np.ones(len(mjds))*ra,
    'star_dec': np.ones(len(mjds))*dec # for later position changes with time
    }
    
    target_info = "<p>Target info" + "<p><hr class=\"target_info\">" 
    target_info+= "Epochs: %i" % len(mjds)
    target_info+= "<p>Survey length: %i d" % int((np.max(mjds) - np.min(mjds)))
    target_info+= "<p>Unique nights: %i" % len(set(mjds.astype(np.int32)))


    data = ColumnDataSource(data)

    click_point_callback = CustomJS(args={"current_src": data}, code=get_image_js)
    tap = TapTool(callback=click_point_callback)

    renderer = p.circle('mjds', 'mags', color=(100,100,255), fill_alpha=0.2, size=6, source=data, nonselection_fill_color='color')
    p.tools.append(tap)

    renderer.selection_glyph = Circle(fill_alpha=1.0, fill_color=(100,100,255), line_color="blue")
    renderer.nonselection_glyph = Circle(fill_alpha=0.2, fill_color=(100,100,255), line_color="blue")


    range_tool = RangeTool(x_range=p.x_range)
    range_tool.overlay.fill_color = "navy"
    range_tool.overlay.fill_alpha = 0.2

    select.line('mjds', 'mags', color=(100,100,255), source=data)
    select.ygrid.grid_line_color = None
    select.add_tools(range_tool)
    select.toolbar.active_multi = range_tool

    return column([p, select]), best_ratchetcamera, target_info

def make_image(ra, dec, cameraratchet):
    gstor = google_cloud.google_storage()
    camera, ratchetid = cameraratchet.split("_")
    print (camera, ratchetid)
    image_data = gstor.download_ratchet_image(camera, ratchetid)
    header = gstor.download_ratchet_image_header(camera, ratchetid)
    wcs = astropy.wcs.WCS(header)

    tx, ty = wcs.all_world2pix(ra,dec,0)

    # make a large cutout around that area, for rotation
    image = Image.open(io.BytesIO(image_data))
    image = image.crop((tx-250,ty-150,tx+250,ty+150))
    image = image.convert("RGB")

    draw = ImageDraw.Draw(image)
    cx, cy = image.width / 2, image.height / 2
    marker_len = 10
    marker_skip = 5
    #draw.ellipse((cx-marker_rad,cy-marker_rad,cx+marker_rad,cy+marker_rad), outline=(100,255,100))
    draw.line((cx - marker_skip, cy, cx - marker_skip - marker_len, cy), fill=(255,50,100))
    draw.line((cx + marker_skip, cy, cx + marker_skip + marker_len, cy), fill=(255,50,100))
    draw.line((cx, cy - marker_skip, cx, cy - marker_skip - marker_len), fill=(255,50,100))
    draw.line((cx, cy + marker_skip, cx, cy + marker_skip + marker_len), fill=(255,50,100))

    image_byte_array = io.BytesIO()
    image.save(image_byte_array,format='jpeg',quality=99)

    return image_byte_array.getvalue()

def make_targets_table(ra,dec,return_list_all=True):
    gstor = google_cloud.google_storage()

    lcs = gstor.get_light_curve(ra, dec)

    out = """<div class="table">"""
    out+= """<div class="table-content">"""

    for lc in lcs:
        out+="""<div class="table-row">"""
        out+="""<div class="table-data">""" + lc[0] + "</div>"
        out+="""<div class="table-data">""" + lc[1] + "</div>"
        out+="""<div class="table-data">""" + lc[2] + "</div>"
        out+="</div>"
    out+="</div>"
    out+="</div>"

    return out

@app.route('/',methods=['GET'])
def root():
    return main_page.render(resources=CDN.render())

@app.route('/target_list/<string:ra>/<string:dec>',methods=['GET'])
def target_display(ra,dec):
    return target_list_page.render(resources=CDN.render(),target_list=target_list)

@app.route('/target_display/<string:ra>/<string:dec>',methods=['GET'])
def target_display(ra,dec):
    return target_display_page.render(resources=CDN.render(),star_ra=ra,star_dec=dec)

@app.route('/plot/<string:ra>/<string:dec>')
def plot(ra,dec):
    ra = float(ra)
    dec = float(dec)
    p, image_spec, target_info = make_plot(ra,dec)
    return json.dumps([json_item(p, "lc_plot"),[ra,dec,image_spec],target_info])


@app.route('/image/<float(signed=True):ra>/<float(signed=True):dec>/<string:cameraratchet>')
def image(ra,dec,cameraratchet):
    image = make_image(ra,dec,cameraratchet)
    return send_file(io.BytesIO(image),
                     attachment_filename='image.jpg',
                     mimetype='image/jpg')

"""
@app.route('/')
def root():
    gstor = google_cloud.google_storage()
    files = gstor.list_files()

    return render_template('index.html', files=files)
"""


if __name__ == '__main__':
    # This is used when running locally only. When deploying to Google App
    # Engine, a webserver process such as Gunicorn will serve the app. This
    # can be configured by adding an `entrypoint` to app.yaml.
    # Flask's development server will automatically serve static files in
    # the "static" directory. See:
    # http://flask.pocoo.org/docs/1.0/quickstart/#static-files. Once deployed,
    # App Engine itself will serve those files as configured in app.yaml.
    app.run(host='127.0.0.1', port=8080, debug=True)
    