import os, configparser, time, zlib
from google.cloud import storage
import google.api_core.exceptions
import numpy as np
import astropy_healpix
import astropy.units as u 
import msgpack
import astropy.coordinates
import healpy

local_config = configparser.ConfigParser()        
local_config.read('config.ini')

class light_curve:
    def __init__(self, mjds, mags, magerrs, limmags, quality, cameras, ratchetids, files):
            self.mjds = mjds
            self.mags = mags
            self.magerrs = magerrs
            self.limmags = limmags 
            self.quality = quality 
            self.cameras = cameras
            self.ratchetids = ratchetids
            self.filenames = files

class google_storage:
    def __init__(self):
        self.client = None
        self.google_service_credentials = local_config['CLOUD']['google_service_credentials']
        self.last_client_use = 0
        self.ratchet_img_cache_loc = "/media/ram/ratchet_imgs/"
        
    def get_session(self):
        if self.client is None or (time.time() - self.last_client_use) > 60.0:
            self.client = storage.Client.from_service_account_json(self.google_service_credentials)
            self.bucket = self.client.bucket(local_config['CLOUD']['light_curves_bucket'])
        return self.client

    def put_object(self, filename, obj_bytes):
        self.get_session()
        blob = self.bucket.blob(filename)
        blob.upload_from_string(obj_bytes) 

    def delete_object(self, filename):
        self.get_session()
        blob = self.bucket.blob(filename)
        blob.delete()

    def download_object(self, filename):
        self.get_session()                                                                         
        blob = self.bucket.blob(filename)
        return blob.download_as_string()
        
    def list_files(self):
        self.get_session()
        files = self.client.list_blobs(local_config['CLOUD']['light_curves_bucket'])
        filenames = []
        for f in files:
            filenames.append(f.name)
        return filenames
    
    def upload_minipix(self, minipix, lc_bytes):
        self.put_object("minipix/%06i.evrlc" % (minipix), lc_bytes)

    def download_minipix(self, minipix):
        try:
            return self.download_object("minipix/%06i.evrlc" % (minipix))
        except google.api_core.exceptions.NotFound:
            return None

    def upload_minipix2(self, minipix, lc_bytes):
        self.put_object("minipix2/%06i.evrlc" % (minipix), lc_bytes)

    def download_minipix2(self, minipix):
        try:
            return self.download_object("minipix2/%06i.evrlc" % (minipix))
        except google.api_core.exceptions.NotFound:
            return None

    def download_healpix_metadata(self, healpix):
        try:
            return self.download_object("healpixes/%06i.evrlc" % (healpix))
        except google.api_core.exceptions.NotFound:
            return None

    def download_epoch_map(self):                                                                                                        return self.download_object("epoch_map.png")  

    def download_ratchet_image(self, camera, ratchetid):
        return self.download_object("ratchet_imgs/ML%s_%s.jpg" % (camera, ratchetid))

    def download_ratchet_image_header(self, camera, ratchetid):
        return zlib.decompress(self.download_object("ratchet_imgs/ML%s_%s.header" % (camera, ratchetid)))
        
    def delete_files_containing_target(self, target):
        for fn in self.list_files():
            if target in fn:
                self.delete_object(fn)

    def unpack_light_curve(self,data,cameras,ratchetids,orig_epoch_n=None,filenames=None):
        minipix_data = np.frombuffer(data, dtype=np.uint16)
        data = np.reshape(minipix_data, (-1, 5))

        mjds = data[:,0] + ((data[:,1].astype(np.float64))/32767.0)
        mags = data[:,2].astype(np.float32) / 1000.0
        magerrs = (data[:,3] >> 8).astype(np.float32) / 255.0
        limmags = ((data[:,3] - ((data[:,3] >> 8) << 8)).astype(np.float32)/255.0)*10.0 + 10.0
        quality = data[:,4].astype(np.float32) / 255.0

        cameras = np.frombuffer(cameras,dtype=np.int64)
        ratchetids = np.frombuffer(ratchetids,dtype=np.int64)
        mask = (mags > 1.0) & (magerrs < 0.9)
        mjds = mjds[mask]
        mags = mags[mask]
        magerrs = np.sqrt((magerrs[mask] ** 2) + 0.01**2)
        limmags = limmags[mask]
        quality = quality[mask]
        
        orig_epoch_n = np.frombuffer(orig_epoch_n,dtype=np.int32)
        print (orig_epoch_n.shape, orig_epoch_n.dtype)
        files = filenames[orig_epoch_n]
        cameras = cameras[orig_epoch_n]
        ratchetids = ratchetids[orig_epoch_n]
        cameras = cameras[mask]
        ratchetids = ratchetids[mask]
        files = files[mask]

        if len(mjds) > 10:
            return light_curve(mjds, mags, magerrs, limmags, quality, cameras, ratchetids, files)
        else:
            return None

    def get_healpix_starlist(self, ra, dec):
        #, return_list_all=False, return_minipix_boundaries=False
        healpix = healpy.ang2pix(32, np.radians((dec*-1.0) + 90.0), np.radians(360.0 - ra))                        
        #healpix_conv = astropy_healpix.HEALPix(nside=32, order='ring')
        #healpix = healpix_conv.lonlat_to_healpix(ra * u.deg, dec * u.deg, return_offsets=False) 


        healpix_metadata = self.download_healpix_metadata(healpix)

        if healpix_metadata is None:
            return None
        
        healpix_metadata = zlib.decompress(healpix_metadata) 
        healpix_starprops, healpix_cameras, healpix_ratchetids, healpix_files = msgpack.unpackb(healpix_metadata,raw=False)
        healpix_files = np.frombuffer(healpix_files, dtype='<U62')
        healpix_cameras = np.frombuffer(healpix_cameras, dtype='int')
        healpix_ratchetids = np.frombuffer(healpix_ratchetids, dtype='int')

        star_list = []

        target = astropy.coordinates.SkyCoord(ra*u.deg, dec*u.deg, frame='fk5')

        for n,star in enumerate(healpix_starprops):
            coords = astropy.coordinates.SkyCoord(star[1]*u.deg, star[2]*u.deg, frame='fk5')
            sep = target.separation(coords)
            star_list.append([sep, n, star[1], star[2], star[3], star[7], star[5], star[6], star[4]])
            
        """
        if return_minipix_boundaries:
            bounds_ra, bounds_dec = healpix_conv.boundaries_lonlat([healpix], step=3)     
            bounds_ra = bounds_ra.to(u.deg).value
            bounds_dec = bounds_dec.to(u.deg).value
            vertices = np.vstack([bounds_ra.ravel(), bounds_dec.ravel()]).transpose()
            return star_list, vertices
        """
        return star_list
        
    def get_light_curve(self, ra, dec, min_rad=1*u.arcmin):
        minipix_conv = astropy_healpix.HEALPix(nside=256, order='ring')
        minipix = minipix_conv.lonlat_to_healpix(ra * u.deg, dec * u.deg, return_offsets=False) 
        healpix = healpy.ang2pix(32, np.radians((dec*-1.0) + 90.0), np.radians(360.0 - ra))                        
        #healpix_conv = astropy_healpix.HEALPix(nside=32, order='ring')
        #healpix = healpix_conv.lonlat_to_healpix(ra * u.deg, dec * u.deg, return_offsets=False) 

        healpix_metadata = self.download_healpix_metadata(healpix)
        
        if healpix_metadata is None:
            return None
        
        healpix_metadata = zlib.decompress(healpix_metadata) 
        healpix_starprops, healpix_cameras, healpix_ratchetids, healpix_files = msgpack.unpackb(healpix_metadata,raw=False)
        healpix_files = np.frombuffer(healpix_files, dtype='<U62')
        healpix_cameras = np.frombuffer(healpix_cameras, dtype='int')
        healpix_ratchetids = np.frombuffer(healpix_ratchetids, dtype='int')

        # should be all minipixes around the target point
        minipix_data = self.download_minipix2(minipix)
        if minipix_data is None:
                return None

        minipix_data = zlib.decompress(minipix_data)
        #       print (minipix_data, memoryview(minipix_data), memoryview(minipix_data).itemsize)
        stars = msgpack.unpackb(minipix_data,raw=False)[0]

        min_dist = 1e5*u.arcmin
        target_n = -1
        target_seps = []
        target = astropy.coordinates.SkyCoord(ra*u.deg, dec*u.deg, frame='fk5')

        for n,star in enumerate(stars):
            star_id = star[0]
            star_ra = star[1]
            star_dec = star[2]
                        
            coords = astropy.coordinates.SkyCoord(star_ra*u.deg, star_dec*u.deg, frame='fk5')
            sep = target.separation(coords)
            target_seps.append(sep)

            if sep < min_dist:
                min_dist = sep
                target_n = n

        if min_dist < min_rad:
            return self.unpack_light_curve(data=stars[target_n][4],cameras=healpix_cameras,ratchetids=healpix_ratchetids,orig_epoch_n=stars[target_n][3],filenames=healpix_files)
        else:
            return None 


if __name__ == "__main__":
    test = google_storage()

    """
    test.upload_star(3000, 1234, b"tgregweg")
    print (test.list_files())

    test.delete_all_stars_in_healpix(3000)
    print (test.list_files())
    
    test.put_object("test.txt", b"Hello world")
    """
    print (test.get_light_curve(22.7362, 32.4181))
